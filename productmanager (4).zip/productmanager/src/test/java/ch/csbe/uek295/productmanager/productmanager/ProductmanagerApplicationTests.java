package ch.csbe.uek295.productmanager.productmanager;

import org.junit.jupiter.api.Test;
import org.springframework.boot.test.context.SpringBootTest;

@SpringBootTest
class ProductmanagerApplicationTests {

    @Test
    void contextLoads() {
    }

}
