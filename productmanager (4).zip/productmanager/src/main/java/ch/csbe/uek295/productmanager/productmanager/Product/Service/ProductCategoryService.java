package ch.csbe.uek295.productmanager.productmanager.Product.Service;

import ch.csbe.uek295.productmanager.productmanager.Product.enitity.ProductCategory;
import ch.csbe.uek295.productmanager.productmanager.Product.Repository.ProductCategoryRepository;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;

import java.util.List;
import java.util.Optional;

@Service
public class ProductCategoryService {

    private final ProductCategoryRepository productCategoryRepository;

    @Autowired
    public ProductCategoryService(ProductCategoryRepository productCategoryRepository) {
        this.productCategoryRepository = productCategoryRepository;
    }

    public List<ProductCategory> getAllCategories() {
        return productCategoryRepository.findAll();
    }

    public Optional<ProductCategory> getCategoryById(long id) {
        return productCategoryRepository.findById(id);
    }

    public ProductCategory createCategory(ProductCategory productCategory) {
        // Additional validation logic can be added here if needed
        return productCategoryRepository.save(productCategory);
    }

    public ProductCategory updateCategory(long id, ProductCategory updatedCategory) {
        if (productCategoryRepository.existsById(id)) {
            updatedCategory.setId(id);
            // Additional validation logic can be added here if needed
            return productCategoryRepository.save(updatedCategory);
        } else {
            // Handle the case when the category with the given ID does not exist
            // You can throw an exception or handle it based on your use case
            return null;
        }
    }

    public void deleteCategory(long id) {
        if (productCategoryRepository.existsById(id)) {
            productCategoryRepository.deleteById(id);
        } else {
            // Handle the case when the category with the given ID does not exist
            // You can throw an exception or handle it based on your use case
        }
    }
}