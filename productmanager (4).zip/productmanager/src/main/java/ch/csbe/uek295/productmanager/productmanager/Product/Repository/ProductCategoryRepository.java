package ch.csbe.uek295.productmanager.productmanager.Product.Repository;

import ch.csbe.uek295.productmanager.productmanager.Product.enitity.ProductCategory;
import org.springframework.data.jpa.repository.JpaRepository;
import org.springframework.stereotype.Repository;

@Repository
public interface ProductCategoryRepository extends JpaRepository<ProductCategory, Long> {
    // You can add custom query methods if needed
}