package ch.csbe.uek295.productmanager.productmanager.Product.auth;

import org.slf4j.Logger;
import org.slf4j.LoggerFactory;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.http.HttpStatus;
import org.springframework.http.ResponseEntity;
import org.springframework.security.authentication.AuthenticationManager;
import org.springframework.security.authentication.BadCredentialsException;
import org.springframework.security.authentication.UsernamePasswordAuthenticationToken;
import org.springframework.security.core.userdetails.UserDetails;
import org.springframework.security.core.userdetails.UserDetailsService;
import org.springframework.web.bind.annotation.ExceptionHandler;
import org.springframework.web.bind.annotation.PostMapping;
import org.springframework.web.bind.annotation.RequestBody;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RestController;

@RestController
@RequestMapping("/auth")
public class AuthController {

    @Autowired
    private UserDetailsService userDetailsService;

    @Autowired
    private AuthenticationManager manager;

    @Autowired
    private JwtHelper helper;

    private Logger logger = LoggerFactory.getLogger(AuthController.class);

    @PostMapping("/login")
    public ResponseEntity<JwtResponse> login(@RequestBody JwtRequest request) {
        logger.info("Received login request for email: {}", request.getUsername());

        try {
            this.doAuthenticate(request.getUsername(), request.getPassword());

            UserDetails userDetails = userDetailsService.loadUserByUsername(request.getUsername());
            String token = this.helper.generateToken(userDetails);

            logger.info("Login successful for user: {}", userDetails.getUsername());
            String username = userDetails.getUsername();
                        
            JwtResponse response = new JwtResponse(token, username);
            

            //logger.info(response.toString());
            return new ResponseEntity<>(response, HttpStatus.OK);

        } catch (BadCredentialsException e) {
            logger.error("Authentication failed for user: {}", request.getUsername());
            throw new BadCredentialsException("Invalid Username or Password!!");
        }
    }


	private void doAuthenticate(String email, String password) {
        logger.info("Authenticating user: {}", email);
        UsernamePasswordAuthenticationToken authentication = new UsernamePasswordAuthenticationToken(email, password);
        manager.authenticate(authentication);
        logger.info("Authentication successful for user: {}", email);
    }

    @ExceptionHandler(BadCredentialsException.class)
    public String exceptionHandler() {
        logger.error("Credentials Invalid!!");
        return "Credentials Invalid !!";
    }
}