package ch.csbe.uek295.productmanager.productmanager.Product.Controller;

import ch.csbe.uek295.productmanager.productmanager.Product.enitity.ProductCategory;
import ch.csbe.uek295.productmanager.productmanager.Product.Service.ProductCategoryService;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.web.bind.annotation.*;

import java.util.List;
import java.util.Optional;

@RestController
@RequestMapping("/api/categories")
public class ProductCategoryController {

    @Autowired
    private ProductCategoryService productCategoryService;

    // Get all product categories
    @GetMapping
    public List<ProductCategory> getAllCategories() {
        return productCategoryService.getAllCategories();
    }

    // Get product category by ID
    @GetMapping("/{id}")
    public Optional<ProductCategory> getCategoryById(@PathVariable long id) {
        return productCategoryService.getCategoryById(id);
    }

    // Create a new product category
    @PostMapping
    public ProductCategory createCategory(@RequestBody ProductCategory productCategory) {
        return productCategoryService.createCategory(productCategory);
    }

    // Update an existing product category
    @PutMapping("/{id}")
    public ProductCategory updateCategory(@PathVariable long id, @RequestBody ProductCategory productCategory) {
        return productCategoryService.updateCategory(id, productCategory);
    }

    // Delete a product category by ID
    @DeleteMapping("/{id}")
    public void deleteCategory(@PathVariable long id) {
        productCategoryService.deleteCategory(id);
    }
}