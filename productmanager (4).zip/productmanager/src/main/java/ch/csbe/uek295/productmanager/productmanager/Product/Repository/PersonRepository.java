package ch.csbe.uek295.productmanager.productmanager.Product.Repository;

import ch.csbe.uek295.productmanager.productmanager.Product.enitity.Person;
import org.springframework.data.jpa.repository.JpaRepository;
import org.springframework.stereotype.Repository;

@Repository
public interface PersonRepository extends JpaRepository<Person, Integer> {
    // You can add custom query methods if needed
}