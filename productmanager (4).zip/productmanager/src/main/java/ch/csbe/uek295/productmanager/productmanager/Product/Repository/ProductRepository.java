package ch.csbe.uek295.productmanager.productmanager.Product.Repository;

import ch.csbe.uek295.productmanager.productmanager.Product.enitity.Product;
import org.springframework.data.jpa.repository.JpaRepository;
import org.springframework.stereotype.Repository;

import java.util.Optional;

@Repository
public interface ProductRepository extends JpaRepository<Product,Long> {
    Optional<Product> findById(int id);
}
