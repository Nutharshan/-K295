package ch.csbe.uek295.productmanager.productmanager.Product;

import org.springframework.boot.SpringApplication;
import org.springframework.boot.autoconfigure.SpringBootApplication;

@SpringBootApplication
public class ProductmanagerApplication {

    public static void main(String[] args) {
        SpringApplication.run(ProductmanagerApplication.class, args);
    }

}
