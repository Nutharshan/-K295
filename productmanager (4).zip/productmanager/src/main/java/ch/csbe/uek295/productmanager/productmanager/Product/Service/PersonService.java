package ch.csbe.uek295.productmanager.productmanager.Product.Service;

import ch.csbe.uek295.productmanager.productmanager.Product.enitity.Person;
import ch.csbe.uek295.productmanager.productmanager.Product.Repository.PersonRepository;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;

import java.util.List;
import java.util.Optional;

@Service
public class PersonService {

    private final PersonRepository personRepository;

    @Autowired
    public PersonService(PersonRepository personRepository) {
        this.personRepository = personRepository;
    }

    public List<Person> getAllPeople() {
        return personRepository.findAll();
    }

    public Optional<Person> getPersonById(Integer id) {
        return personRepository.findById(id);
    }

    public Person createPerson(Person person) {
        // Additional validation logic can be added here if needed
        return personRepository.save(person);
    }

    public Person updatePerson(Integer id, Person updatedPerson) {
        if (personRepository.existsById(id)) {
            updatedPerson.setId(id);
            // Additional validation logic can be added here if needed
            return personRepository.save(updatedPerson);
        } else {
            // Handle the case when the person with the given ID does not exist
            // You can throw an exception or handle it based on your use case
            return null;
        }
    }

    public void deletePerson(Integer id) {
        if (personRepository.existsById(id)) {
            personRepository.deleteById(id);
        } else {
            // Handle the case when the person with the given ID does not exist
            // You can throw an exception or handle it based on your use case
        }
    }
}