package ch.csbe.uek295.productmanager.productmanager.Product.auth;

import com.fasterxml.jackson.annotation.JsonProperty;

import lombok.AllArgsConstructor;
import lombok.Builder;
import lombok.Getter;
import lombok.NoArgsConstructor;
import lombok.Setter;
import lombok.ToString;

@AllArgsConstructor
@NoArgsConstructor
@ToString
@Builder
public class JwtRequest {
	@JsonProperty("username")
	private String username;
	
	@JsonProperty
	private String password;
	
	// Getter for Email with JSON property annotation
    @JsonProperty("username")
    public String getUsername() {
        return username;
    }

    // Setter for Email with JSON property annotation
    @JsonProperty("email")
    public void setUsername(String username) {
        this.username = username;
    }

    // Getter for Password with JSON property annotation
    @JsonProperty("password")
    public String getPassword() {
        return password;
    }

    // Setter for Password with JSON property annotation
    @JsonProperty("password")
    public void setPassword(String password) {
        this.password = password;
    }
}
